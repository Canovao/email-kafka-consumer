package br.com.dbc.vemser.financeiro.emailkafkaconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailKafkaConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
