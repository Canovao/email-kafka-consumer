package br.com.dbc.vemser.financeiro.emailkafkaconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailKafkaConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailKafkaConsumerApplication.class, args);
	}

}
